<?php
/* Smarty version 5.4.5, created on 2025-05-27 13:22:52
  from 'file:home.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6835a08cd82e63_90680960',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e0e1060d056ab2a0f676fc32c733f09a8fc9533d' => 
    array (
      0 => 'home.tpl',
      1 => 1748015094,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6835a08cd82e63_90680960 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_19552701876835a08cd787e0_10561711', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_19552701876835a08cd787e0_10561711 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views';
?>

  <section class="hero">
    <div class="hero-content container">
      <h1>Witaj w Planerze zadań</h1>
      <p>Zarządzaj zadaniami swojego zespołu szybko i wygodnie.</p>
      <div class="hero-buttons">
        <?php if (!$_smarty_tpl->getValue('user')) {?>
          <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
login"    class="btn btn--primary">Zaloguj się</a>
          <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
register" class="btn btn--secondary">Utwórz konto</a>
        <?php } else { ?>
          <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
list" class="btn btn--primary">Przejdź do zadań</a>
        <?php }?>
      </div>
    </div>
  </section>

  <section class="news container">
    <h2>Aktualności</h2>
    <?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('news'))) {?>
      <div class="news-grid">
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('news'), 'item');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('item')->value) {
$foreach0DoElse = false;
?>
          <article class="news-card">
            <h3><?php echo $_smarty_tpl->getValue('item')['title'];?>
</h3>
            <time datetime="<?php echo $_smarty_tpl->getValue('item')['date'];?>
"><?php echo $_smarty_tpl->getValue('item')['date'];?>
</time>
            <p><?php echo $_smarty_tpl->getValue('item')['summary'];?>
</p>
            <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
news/<?php echo $_smarty_tpl->getValue('item')['id'];?>
" class="read-more">Czytaj dalej →</a>
          </article>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </div>
    <?php } else { ?>
      <p class="no-news">Brak aktualności.</p>
    <?php }?>
  </section>
<?php
}
}
/* {/block "content"} */
}
