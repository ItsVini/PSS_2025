<?php
/* Smarty version 5.4.5, created on 2025-05-27 13:38:04
  from 'file:user/list.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6835a41c122487_47779218',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '86e49b31385cd3578a52d1c7c1815876c03b0b2f' => 
    array (
      0 => 'user/list.tpl',
      1 => 1748345883,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6835a41c122487_47779218 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\user';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_13767909246835a41c116349_91815623', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_13767909246835a41c116349_91815623 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\user';
?>

  <div class="container user-management">
    <h2 class="section-title">Zarządzaj użytkownikami</h2>

    <div class="table-wrapper">
      <table class="user-table">
        <thead>
          <tr>
            <th>Imię i nazwisko</th>
            <th>E-mail</th>
            <th>Rola</th>
            <th>Akcje</th>
          </tr>
        </thead>
        <tbody>
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('users'), 'u');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('u')->value) {
$foreach0DoElse = false;
?>
            <tr>
              <td><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('u')['first_name'], ENT_QUOTES, 'UTF-8', true);?>
 <?php echo htmlspecialchars((string)$_smarty_tpl->getValue('u')['last_name'], ENT_QUOTES, 'UTF-8', true);?>
</td>
              <td><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('u')['email'], ENT_QUOTES, 'UTF-8', true);?>
</td>
              <td>
                <?php if ((true && (true && null !== ($_smarty_tpl->getValue('roleMap')[$_smarty_tpl->getValue('u')['role_id']] ?? null)))) {?>
                  <?php echo htmlspecialchars((string)$_smarty_tpl->getSmarty()->getModifierCallback('capitalize')($_smarty_tpl->getValue('roleMap')[$_smarty_tpl->getValue('u')['role_id']]), ENT_QUOTES, 'UTF-8', true);?>

                <?php } else { ?>
                  –  
                <?php }?>
              </td>
              <td>
                                <?php if ($_smarty_tpl->getValue('u')['role_id'] < 4) {?>
                  <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
userEdit&id=<?php echo $_smarty_tpl->getValue('u')['id'];?>
"
                     class="btn btn--small btn--primary">
                    Zmień rolę
                  </a>
                <?php } else { ?>
                  <span style="color:#999;font-style:italic;">—</span>
                <?php }?>
              </td>
            </tr>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </tbody>
      </table>
    </div>
  </div>
<?php
}
}
/* {/block "content"} */
}
