<?php
/* Smarty version 5.4.5, created on 2025-05-30 21:41:08
  from 'file:auth/login.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_683a09d44904c6_06291715',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '69360a31bee384522f1c7b8cb0b01650ef6dee04' => 
    array (
      0 => 'auth/login.tpl',
      1 => 1748633969,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_683a09d44904c6_06291715 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\auth';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_81823459683a09d43f3647_03113412', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_81823459683a09d43f3647_03113412 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\auth';
?>

  <div class="form-container container">
    <h2>Logowanie</h2>

    <?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="errors">
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'msg');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach0DoElse = false;
?>
          <p class="error"><?php echo $_smarty_tpl->getValue('msg')->text;?>
</p>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </div>
    <?php }?>

    <form method="post" action="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
login" class="auth-form">
      <label>
        Login:
        <input type="text" name="username" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['username'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>
      <label>
        Hasło:
        <input type="password" name="password">
      </label>
      <button type="submit" class="btn btn--primary">Zaloguj</button>
    </form>
  </div>
<?php
}
}
/* {/block "content"} */
}
