<?php
/* Smarty version 5.4.5, created on 2025-05-28 11:03:50
  from 'file:E:\xamp\htdocs\amelia\app\views\auth\../layouts/main.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6836d1767a3e67_43893858',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '45c90d4ad70b2ca45c26e532b150ca2bb02a626c' => 
    array (
      0 => 'E:\\xamp\\htdocs\\amelia\\app\\views\\auth\\../layouts/main.tpl',
      1 => 1748423026,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6836d1767a3e67_43893858 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\layouts';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo (($tmp = $_smarty_tpl->getValue('conf')->app_name ?? null)===null||$tmp==='' ? 'Planer zadań' ?? null : $tmp);?>
</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
home" class="logo">Planer zadań</a>
      <nav>
        <ul class="nav-list">
          <li><a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
home">Strona główna</a></li>
          <?php if ($_smarty_tpl->getValue('user') && $_smarty_tpl->getValue('user')['role_id'] == 4) {?>
            <li><a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
users">Zarządzaj użytkownikami</a></li>
          <?php }?>
          <?php if ($_smarty_tpl->getValue('user')) {?>
          <?php if ($_smarty_tpl->getValue('user') && $_smarty_tpl->getValue('user')['role_id'] != 1) {?>
            <li><a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
list">Moje zadania</a></li>
            <?php }?>
            <li><a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
logout">Wyloguj (<?php echo $_smarty_tpl->getValue('user')['username'];?>
)</a></li>
          <?php } else { ?>
            <li><a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
login">Zaloguj</a></li>
            <li><a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
register">Rejestracja</a></li>
          <?php }?>
        </ul>
      </nav>
    </div>
  </header>

  <main class="site-main container">
    
    <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_18361699016836d1767a1f43_67407850', "content");
?>

  </main>
</body>
</html>
<?php }
/* {block "content"} */
class Block_18361699016836d1767a1f43_67407850 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\layouts';
}
}
/* {/block "content"} */
}
