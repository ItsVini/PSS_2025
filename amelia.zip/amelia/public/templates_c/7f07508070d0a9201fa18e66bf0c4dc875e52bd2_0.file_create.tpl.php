<?php
/* Smarty version 5.4.5, created on 2025-05-27 13:23:06
  from 'file:task/create.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6835a09a665090_16574774',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7f07508070d0a9201fa18e66bf0c4dc875e52bd2' => 
    array (
      0 => 'task/create.tpl',
      1 => 1748344492,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6835a09a665090_16574774 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\task';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_10110356986835a09a656ef2_75708438', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_10110356986835a09a656ef2_75708438 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\task';
?>

  <div class="form-container">
    <h2>Nowe zadanie</h2>

    <?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="errors">
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'm');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach0DoElse = false;
?>
          <p class="error"><?php echo $_smarty_tpl->getValue('m')->text;?>
</p>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </div>
    <?php }?>

    <form method="post" action="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
create" class="task-form">
      <label>
        Tytuł:
        <input type="text" name="title" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['title'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>

      <label>
        Od:
        <input type="date" name="start_date" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['start_date'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>

      <label>
        Do:
        <input type="date" name="end_date" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['end_date'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>

      <?php if ($_smarty_tpl->getValue('isMgr')) {?>
        <label>
          Przypisz do:
          <select name="assigned_to">
            <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('employees'), 'e');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('e')->value) {
$foreach1DoElse = false;
?>
              <option 
                value="<?php echo $_smarty_tpl->getValue('e')['id'];?>
"
                <?php if ((($tmp = $_smarty_tpl->getValue('form')['assigned_to'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp) == $_smarty_tpl->getValue('e')['id']) {?>selected<?php }?>
              >
                <?php echo htmlspecialchars((string)$_smarty_tpl->getValue('e')['first_name'], ENT_QUOTES, 'UTF-8', true);?>
 <?php echo htmlspecialchars((string)$_smarty_tpl->getValue('e')['last_name'], ENT_QUOTES, 'UTF-8', true);?>

              </option>
            <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
          </select>
        </label>
      <?php }?>

      <label>
        Komentarz (opcjonalnie):
        <textarea 
          name="comment" 
          class="form-textarea"
          placeholder="Pierwszy komentarz…"
        ><?php echo (($tmp = $_smarty_tpl->getValue('form')['comment'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
</textarea>
      </label>

      <div class="form-buttons">
        <button type="submit" class="btn btn--primary">Utwórz zadanie</button>
        <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
list" class="btn btn--secondary">Anuluj</a>
      </div>
    </form>
  </div>
<?php
}
}
/* {/block "content"} */
}
