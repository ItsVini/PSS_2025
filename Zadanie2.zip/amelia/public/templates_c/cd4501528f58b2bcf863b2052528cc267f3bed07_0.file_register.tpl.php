<?php
/* Smarty version 5.4.5, created on 2025-05-28 10:18:05
  from 'file:auth/register.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6836c6bd810591_22169165',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd4501528f58b2bcf863b2052528cc267f3bed07' => 
    array (
      0 => 'auth/register.tpl',
      1 => 1748024316,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6836c6bd810591_22169165 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\auth';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_2532368456836c6bd682022_34868123', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_2532368456836c6bd682022_34868123 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\auth';
?>

  <div class="form-container container">
    <h2>Rejestracja</h2>

    <?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="errors">
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'msg');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach0DoElse = false;
?>
          <p class="error"><?php echo $_smarty_tpl->getValue('msg')->text;?>
</p>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </div>
    <?php }?>

    <form method="post" action="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
register" class="auth-form">
      <label>Login:
        <input type="text" name="username" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['username'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>
      <label>Imię:
        <input type="text" name="first_name" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['first_name'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>
      <label>Nazwisko:
        <input type="text" name="last_name" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['last_name'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>
      <label>E-mail:
        <input type="email" name="email" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['email'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
">
      </label>
      <label>Hasło:
        <input type="password" name="password">
      </label>
      <label>Potwierdź hasło:
        <input type="password" name="password_confirm">
      </label>
      <button type="submit" class="btn btn--primary">Załóż konto</button>
    </form>
  </div>
<?php
}
}
/* {/block "content"} */
}
