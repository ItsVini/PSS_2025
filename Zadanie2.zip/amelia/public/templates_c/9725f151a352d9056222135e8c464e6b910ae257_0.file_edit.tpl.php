<?php
/* Smarty version 5.4.5, created on 2025-05-27 13:31:31
  from 'file:user/edit.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6835a293258975_60271060',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9725f151a352d9056222135e8c464e6b910ae257' => 
    array (
      0 => 'user/edit.tpl',
      1 => 1748029060,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6835a293258975_60271060 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\user';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_9047439856835a29324e116_50211250', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_9047439856835a29324e116_50211250 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\user';
?>

  <div class="container">
    <h2>Zmień rolę użytkownika: <?php echo $_smarty_tpl->getValue('userToEdit')['username'];?>
</h2>

    <?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="errors">
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'msg');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach0DoElse = false;
?>
          <p class="error"><?php echo $_smarty_tpl->getValue('msg')->text;?>
</p>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </div>
    <?php }?>

    <form method="post" action="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
userEdit" class="role-form">
      <input type="hidden" name="id" value="<?php echo $_smarty_tpl->getValue('userToEdit')['id'];?>
">
      <label>Nowa rola:
        <select name="role_id">
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('roles'), 'r');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('r')->value) {
$foreach1DoElse = false;
?>
            <option value="<?php echo $_smarty_tpl->getValue('r')['id'];?>
" <?php if ($_smarty_tpl->getValue('r')['id'] == $_smarty_tpl->getValue('userToEdit')['role_id']) {?>selected<?php }?>>
              <?php echo $_smarty_tpl->getValue('r')['name'];?>

            </option>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </select>
      </label>
      <div class="form-buttons">
  <button type="submit" class="btn btn--primary">Zapisz</button>
  <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
home" class="btn btn--secondary">Anuluj</a>
</div>
    </form>
  </div>
<?php
}
}
/* {/block "content"} */
}
