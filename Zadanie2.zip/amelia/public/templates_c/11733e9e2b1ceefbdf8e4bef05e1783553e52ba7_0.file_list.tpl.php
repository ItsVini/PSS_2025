<?php
/* Smarty version 5.4.5, created on 2025-05-30 21:41:13
  from 'file:task/list.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_683a09d9d74514_84717076',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11733e9e2b1ceefbdf8e4bef05e1783553e52ba7' => 
    array (
      0 => 'task/list.tpl',
      1 => 1748634024,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_683a09d9d74514_84717076 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\task';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_603586109683a09d9cfc9d8_58697148', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_603586109683a09d9cfc9d8_58697148 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\task';
?>

<?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="errors">
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'm');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach0DoElse = false;
?>
          <p class="error"><?php echo $_smarty_tpl->getValue('m')->text;?>
</p>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </div>
    <?php }?>
  <div class="container">

    <form
      method="get"
      action="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
list"
      class="filter-form"
    >
      <input type="hidden" name="action" value="list">

      <input
        type="text"
        name="search"
        placeholder="Szukaj po tytule..."
        value="<?php echo htmlspecialchars((string)$_smarty_tpl->getValue('search'), ENT_QUOTES, 'UTF-8', true);?>
"
      >

      <select name="status">
        <option value="">Wszystkie statusy</option>
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('statuses'), 's');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('s')->value) {
$foreach1DoElse = false;
?>
          <option value="<?php echo $_smarty_tpl->getValue('s')['id'];?>
"
                  <?php if ($_smarty_tpl->getValue('statusFilter') === $_smarty_tpl->getValue('s')['id']) {?>selected<?php }?>>
            <?php if ($_smarty_tpl->getValue('s')['name'] == 'new') {?>Nowe
            <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'in_progress') {?>W realizacji
            <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'completed') {?>Zakończone
            <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'closed') {?>Zamknięte<?php }?>
          </option>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </select>

      <?php if ($_smarty_tpl->getValue('user')['role_id'] >= 3) {?>
        <select name="assigned">
          <option value="">Wszyscy pracownicy</option>
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('employees'), 'e');
$foreach2DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('e')->value) {
$foreach2DoElse = false;
?>
            <option value="<?php echo $_smarty_tpl->getValue('e')['id'];?>
"
                    <?php if ($_smarty_tpl->getValue('assignedFilter') === $_smarty_tpl->getValue('e')['id']) {?>selected<?php }?>>
              <?php echo $_smarty_tpl->getValue('e')['first_name'];?>
 <?php echo $_smarty_tpl->getValue('e')['last_name'];?>

            </option>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </select>
      <?php }?>

      <button type="submit" class="btn btn--small btn--primary">Filtruj</button>
      <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
list" class="btn btn--small btn--secondary">Wyczyść</a>
      
    </form>

    <div class="board-columns">
      <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('statuses'), 's');
$foreach3DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('s')->value) {
$foreach3DoElse = false;
?>
        <div class="column column-<?php echo $_smarty_tpl->getValue('s')['name'];?>
">
          <h3>
            <?php if ($_smarty_tpl->getValue('s')['name'] == 'new') {?>Nowe
            <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'in_progress') {?>W realizacji
            <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'completed') {?>Zakończone
            <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'closed') {?>Zamknięte<?php }?>
          </h3>
          <ul class="task-list">
            <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('board')[$_smarty_tpl->getValue('s')['id']], 't');
$foreach4DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('t')->value) {
$foreach4DoElse = false;
?>
              <li class="task-card">
                <h4><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('t')['title'], ENT_QUOTES, 'UTF-8', true);?>
</h4>
                <small>Przypisane: <?php echo htmlspecialchars((string)$_smarty_tpl->getValue('t')['assigned_name'], ENT_QUOTES, 'UTF-8', true);?>
</small>
                <small>Od: <?php echo $_smarty_tpl->getValue('t')['start_date'];?>
</small>
                <small>Do: <?php echo $_smarty_tpl->getValue('t')['end_date'];?>
</small>
                <div class="task-actions">
                  <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
edit&id=<?php echo $_smarty_tpl->getValue('t')['id'];?>
" class="btn btn--small">Edytuj</a>
                </div>
              </li>
            <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
            <?php if (!$_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('board')[$_smarty_tpl->getValue('s')['id']])) {?>
              <li class="no-task">Brak zadań</li>
            <?php }?>
          </ul>
        </div>
      <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
    </div>
    <?php if ($_smarty_tpl->getValue('user')) {?>
      <div class="create-task" style="text-align: right; margin-bottom:1rem;">
        <a href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
create" class="btn btn--primary">+ Nowe zadanie</a>
      </div>
    <?php }?>

  </div>
<?php
}
}
/* {/block "content"} */
}
