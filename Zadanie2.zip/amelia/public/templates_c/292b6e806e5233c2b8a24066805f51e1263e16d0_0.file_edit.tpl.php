<?php
/* Smarty version 5.4.5, created on 2025-05-30 21:48:21
  from 'file:task/edit.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_683a0b85e926d1_17226414',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '292b6e806e5233c2b8a24066805f51e1263e16d0' => 
    array (
      0 => 'task/edit.tpl',
      1 => 1748634009,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_683a0b85e926d1_17226414 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\task';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_423900959683a0b85e7f4b0_09081142', "content");
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../layouts/main.tpl", $_smarty_current_dir);
}
/* {block "content"} */
class Block_423900959683a0b85e7f4b0_09081142 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'E:\\xamp\\htdocs\\amelia\\app\\views\\task';
?>

<?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="errors">
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'm');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach0DoElse = false;
?>
          <p class="error"><?php echo $_smarty_tpl->getValue('m')->text;?>
</p>
        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
      </div>
    <?php }?>
  <div class="container edit-layout">

  

    <div class="edit-col">
      <h2>Edytuj zadanie</h2>

      <form method="post" action="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
edit" id="editForm" class="auth-form">
        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->getValue('task')['id'];?>
">

        <label>Tytuł:
          <input type="text" name="title" value="<?php echo htmlspecialchars((string)$_smarty_tpl->getValue('task')['title'], ENT_QUOTES, 'UTF-8', true);?>
">
        </label>

        <label>Od:
          <input type="date" name="start_date" value="<?php echo $_smarty_tpl->getValue('task')['start_date'];?>
">
        </label>

        <label>Do:
          <input type="date" name="end_date" value="<?php echo $_smarty_tpl->getValue('task')['end_date'];?>
">
        </label>

        <label>Status:
          <select name="status_id">
    <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('statuses'), 's');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('s')->value) {
$foreach1DoElse = false;
?>
      <option value="<?php echo $_smarty_tpl->getValue('s')['id'];?>
" <?php if ($_smarty_tpl->getValue('s')['id'] == $_smarty_tpl->getValue('task')['status_id']) {?>selected<?php }?>>
        <?php if ($_smarty_tpl->getValue('s')['name'] == 'new') {?>Nowe
        <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'in_progress') {?>W realizacji
        <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'completed') {?>Zakończone
        <?php } elseif ($_smarty_tpl->getValue('s')['name'] == 'closed') {?>Zamknięte
        <?php } else {
echo $_smarty_tpl->getSmarty()->getModifierCallback('capitalize')($_smarty_tpl->getValue('s')['name']);
}?>
      </option>
    <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
          </select>
        </label>

        <?php if ($_smarty_tpl->getValue('isMgr')) {?>
          <label>Przypisz do:
            <select name="assigned_to">
              <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('employees'), 'e');
$foreach2DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('e')->value) {
$foreach2DoElse = false;
?>
                <option value="<?php echo $_smarty_tpl->getValue('e')['id'];?>
" <?php if ($_smarty_tpl->getValue('e')['id'] == $_smarty_tpl->getValue('task')['assigned_to']) {?>selected<?php }?>>
                  <?php echo $_smarty_tpl->getValue('e')['first_name'];?>
 <?php echo $_smarty_tpl->getValue('e')['last_name'];?>

                </option>
              <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
            </select>
          </label>
        <?php }?>
      </form>

      <form method="post" action="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
taskComment" id="commentForm" class="comment-form">
        <input type="hidden" name="task_id" value="<?php echo $_smarty_tpl->getValue('task')['id'];?>
">
        <label>Nowy komentarz:
          <textarea name="content" rows="3" required><?php echo (($tmp = $_smarty_tpl->getValue('form')['content'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
</textarea>
        </label>
      </form>

      <div class="form-buttons">
        <button type="submit" form="editForm"    class="btn btn--primary">Zapisz</button>
        <a      href="<?php echo $_smarty_tpl->getValue('conf')->action_root;?>
list" class="btn btn--secondary">Anuluj</a>
        <button type="submit" form="commentForm" class="btn btn--primary">Dodaj komentarz</button>
      </div>
    </div>

    <div class="comments-col">
      <h3>Komentarze</h3>

      <?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('comments'))) {?>
        <div class="comments-list">
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('comments'), 'c');
$foreach3DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('c')->value) {
$foreach3DoElse = false;
?>
            <div class="comment-card">
              <div class="meta">
                <strong><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('commentAuthors')[$_smarty_tpl->getValue('c')['author_id']], ENT_QUOTES, 'UTF-8', true);?>
</strong>
                <span>&middot; <?php echo $_smarty_tpl->getValue('c')['created_at'];?>
</span>
              </div>
              <p><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('c')['content'], ENT_QUOTES, 'UTF-8', true);?>
</p>
            </div>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </div>
      <?php } else { ?>
        <p class="no-comments">Brak komentarzy.</p>
      <?php }?>
    </div>

  </div>
<?php
}
}
/* {/block "content"} */
}
